<?php
require_once'classe-pessoa.php';
$p = new Pessoa("crudpdo","localhost","root","");
?>
<!DOCTYPE HTML>
<!--
	Traveler by freehtml5.co
	Twitter: http://twitter.com/fh5co
	URL: http://freehtml5.co
-->
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>HB MARKET &mdash; </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by FreeHTML5.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="FreeHTML5.co" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">

	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		<?php
		if(isset($_POST['nome']))
		{
			$nome = trim($_POST['nome']);
			$usuario = trim($_POST['usuario']);
			$senha = trim($_POST['senha']);
			if(!empty($nome) && !empty($usuario) && !empty($senha))
			{
				if(!$p->cadastrarPessoa($nome, $usuario, $senha))
				{
					echo "Usuario ja esta cadastrado!";
				}
			}
			else
			{
				echo "Preencha todos os campos";
			}
		}
		?>


	<div class="gtco-loader"></div>

	<div id="page">


	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">

			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.php">HB MARKET <em>.</em></a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
						<li><a href="destination.html">Tênis</a></li>
						<li class="has-dropdown">

						</li>
						
						<li><a href="contact.php">Cadastros</a></li>
					</ul>
				</div>
			</div>

		</div>
	</nav>

	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url(images/img_bg_2.jpg)">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">


					<div class="row row-mt-15em">
						<div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">

							<h1>Isso é o hype!</h1><br><br>
						</div>

						

						<div class="col-md-4 col-md-push-1 animate-box" data-animate-effect="fadeInRight">
							<div class="form-wrap">
								<div class="tab">

									<div class="tab-content">
										<div class="tab-content-inner active" data-content="signup">
											<h3>Cadastrar</h3><br>
											
														
													<div class="box">
                        <form  method="POST">
                            <div class="field">
                                <div class="control">

														<label for="fullname">Email</label>
														<input name="nome" type="text" id="fullname" class="form-control" placeholder="@gmail.com">

													</div>
												</div>

							

												<div class="row form-group">
													<div class="col-md-12">
														<label for="fullname">Usuario</label>
														<input name="usuario" type="text" id="fullname" class="form-control">
													</div>
												</div>
												<div class="row form-group">
													<div class="col-md-12">
														<label for="fullname">Senha</label>
														<input name="senha" type="password" id="fullname" class="form-control">

													</div>
												</div>
											</from>
										</div>

												<div class="row form-group">
													<div class="col-md-12">
														<input type="submit" class="btn btn-primary btn-block" value="Cadastrar">
													</div>
												</div>
												<div class="row form-group">
													<div class="col-md-12">
														<input type="submit" class="btn btn-primary btn-block" value="Cancelar"></div></div></form></div>
													</div>
												</div>
											</form> 
										</div>


									</div>
								</div>
							</div>
						</div>
					</div>


				</div>
			</div>
		</div>
	</header>

	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<br><br><br><h2>Os tênis mais populares</h2>

				</div>
			</div>
			<div class="row">

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="https://d26lpennugtm8s.cloudfront.net/stores/536/783/products/nike-air-max-90-leather-branco1-238a055051d83c2e2415242398444006-1024-1024.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="https://d26lpennugtm8s.cloudfront.net/stores/536/783/products/nike-air-max-90-leather-branco1-238a055051d83c2e2415242398444006-1024-1024.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Tênis Nike Air Max 90</h2>
							<p> (Branco 34-45)</p>
							<p><span class="btn btn-primary">Comprar</span></p>
						</div>
					</a>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="https://wavesoutlet.com.br/wp-content/uploads/2018/04/preto-2.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="https://wavesoutlet.com.br/wp-content/uploads/2018/04/preto-2.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Tênis Adidas Nmd R1 Pk</h2>
							<p>(Preto 34-44)</p>
							<p><span class="btn btn-primary">Comprar</span></p>
						</div>
					</a>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="https://www.outlettenis.com.br/wp-content/uploads/2019/05/yeezy-bosot-preto-e-vermelho.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="https://www.outlettenis.com.br/wp-content/uploads/2019/05/yeezy-bosot-preto-e-vermelho.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Tênis Adidas Yeezy Boost 350 V2</h2>
							<p>(Preto 38-44)</p>
							<p><span class="btn btn-primary">Comprar</span></p>
						</div>
					</a>
				</div>


				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="http://2app.kicksonfire.com/kofapp/upload/events_master_images/ipad_0b58e618962cb44bc653261a39af2ebe5b07527428664.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="http://2app.kicksonfire.com/kofapp/upload/events_master_images/ipad_0b58e618962cb44bc653261a39af2ebe5b07527428664.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Travis Scott X Air Jordan 4 Cactus Jack Houston Oilers</h2>
							<p>(Azul 38-44)</p>
							<p><span class="btn btn-primary">Comprar</span></p>
						</div>
					</a>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="https://cdn.shopify.com/s/files/1/2358/2817/products/Wethenew-Sneakers-France-Air-Force-1-Off-White-Volt-1.png?v=1545054586" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="https://cdn.shopify.com/s/files/1/2358/2817/products/Wethenew-Sneakers-France-Air-Force-1-Off-White-Volt-1.png?v=1545054586" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Air Force 1 Low Off-White Volt</h2>
							<p>(Amarelo fluorescente 38-44)</p>
							<p><span class="btn btn-primary">Comprar</span></p>
						</div>
					</a>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="https://stockx-360.imgix.net/Balenciaga-Speed-Trainer-Black-White-Logo/Images/Balenciaga-Speed-Trainer-Black-White-Logo/Lv2/img01.jpg?auto=format,compress&w=559&q=90&dpr=2&updated_at=1559767254" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="https://stockx-360.imgix.net/Balenciaga-Speed-Trainer-Black-White-Logo/Images/Balenciaga-Speed-Trainer-Black-White-Logo/Lv2/img01.jpg?auto=format,compress&w=559&q=90&dpr=2&updated_at=1559767254" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>Balenciaga Speed Trainer Black</h2>
							<p>(Preto 34-44)</p>
							<p><span class="btn btn-primary">Comprar</span></p>
						</div>
					</a>
				</div>

			</div>
		</div>
	</div>



	<footer id="gtco-footer" role="contentinfo">
		<div class="gtco-container">
			<div class="row row-p	b-md">

				<div class="col-md-4">
					<div class="gtco-widget">
						<h3>Observações da loja</h3>
						<p>Todos produtos apresentados na loja são originais e acompanha nota fiscal.<br>
						   </p>
					</div>
				</div>

				<div class="col-md-2 col-md-push-1">
					<div class="gtco-widget">

						<h3>Frete grátis</h3><br>
						<figure>
							<img src="https://cdn.pixabay.com/photo/2017/10/16/03/08/shipping-2856031_960_720.png" alt="some text" width=100 height=80>
						</figure>

					</div>
				</div>

				<div class="col-md-3 col-md-push-1">
					<div class="gtco-widget">
						<h3>Contato</h3>
						<ul class="gtco-quick-contact">
							<li><a href="#"><i class="icon-phone"></i> +55(11)4002-8922</a></li>
							<li><a href="#"><i class="icon-mail2"></i> silviosantos@gmail.com</a></li>
						</ul>
					</div>
				</div>

			</div>

			<div class="row copyright">
				<div class="col-md-12">

					<p class="pull-right">
						<ul class="gtco-social-icons pull-right">
							<li><a href="https://www.instagram.com/harlleybenzael/"><i class="icon-instagram"></i></a></li>
							<li><a href="https://www.facebook.com/harlley.araujo?ref=bookmarks"><i class="icon-facebook"></i></a></li>
							<li><a href="https://www.linkedin.com/in/harlley-benzael-ara%C3%BAjo-5357a8180/"><i class="icon-linkedin"></i></a></li>
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>
	<!-- </div> -->

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>

	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>

	<!-- Datepicker -->
	<script src="js/bootstrap-datepicker.min.js"></script>


	<!-- Main -->
	<script src="js/main.js"></script>
	</body>
</html>
